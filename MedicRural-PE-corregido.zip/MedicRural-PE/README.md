# MedicRural-PE

Prototipo académico en Python para controlar el inventario de medicamentos e identificar establecimientos rurales con riesgo de desabastecimiento ante desastres naturales.

## Archivos
- `main.py`: menú y flujo principal.
- `inventario.py`: registro, lectura y escritura del archivo de texto.
- `prioridades.py`: clasificación y priorización usando `filter`, `map` y `sorted`.
- `medicamentos.txt`: datos de inventario separados por `|` (establecimiento, medicamento, cantidad, mínimo).

## Ejecutar
En una terminal, dentro de la carpeta del proyecto:

```bash
python main.py
```

En Google Colab, sube y descomprime el ZIP y ejecuta `%run /content/MedicRural-PE/main.py` (ajusta la ruta según la carpeta).

## Git y GitHub: evidencia real
Crea un repositorio y registra avances reales con `git add`, `git commit` y `git push`. Ejemplos de etapas para construirlo progresivamente:
1. Estructura inicial y menú.
2. Registro y guardado en TXT.
3. Análisis de riesgo y priorización funcional.
4. Pruebas y documentación.

No inventes historial: si ya tienes el código final, puedes documentar las versiones de manera transparente o desarrollar mejoras en commits posteriores.

Capturas sugeridas: código de los tres módulos, ejecución del menú, listado de riesgos y pestaña **Commits** de GitHub.
