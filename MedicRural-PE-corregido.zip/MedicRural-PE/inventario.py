"""Registro y persistencia de inventario en archivo de texto."""
from pathlib import Path

RUTA = Path(__file__).with_name('medicamentos.txt')


def cargar_inventario():
    registros = []
    if not RUTA.exists():
        return registros
    for linea in RUTA.read_text(encoding='utf-8').splitlines():
        if not linea.strip() or linea.startswith('#'):
            continue
        partes = linea.split('|')
        if len(partes) != 4:
            continue
        establecimiento, medicamento, cantidad, minimo = partes
        try:
            registros.append({'establecimiento': establecimiento, 'medicamento': medicamento,
                              'cantidad': int(cantidad), 'minimo': int(minimo)})
        except ValueError:
            continue
    return registros


def guardar_inventario(registros):
    lineas = [f"{r['establecimiento']}|{r['medicamento']}|{r['cantidad']}|{r['minimo']}" for r in registros]
    RUTA.write_text('\n'.join(lineas) + ('\n' if lineas else ''), encoding='utf-8')


def registrar_medicamento(registros, establecimiento, medicamento, cantidad, minimo):
    if not establecimiento.strip() or not medicamento.strip() or '|' in establecimiento + medicamento:
        raise ValueError('Nombre inválido.')
    if cantidad < 0 or minimo < 0:
        raise ValueError('Las cantidades no pueden ser negativas.')
    nuevo = {'establecimiento': establecimiento.strip(), 'medicamento': medicamento.strip(),
             'cantidad': cantidad, 'minimo': minimo}
    registros.append(nuevo)
    guardar_inventario(registros)
    return nuevo
