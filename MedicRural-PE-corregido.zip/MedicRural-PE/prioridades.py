"""Análisis de riesgo mediante programación funcional."""


def nivel_riesgo(registro):
    if registro['cantidad'] == 0:
        return 'ALTO'
    if registro['cantidad'] < registro['minimo']:
        return 'MEDIO'
    return 'BAJO'


def establecimientos_en_riesgo(registros):
    filtrados = filter(lambda r: nivel_riesgo(r) != 'BAJO', registros)
    transformados = map(lambda r: {**r, 'riesgo': nivel_riesgo(r)}, filtrados)
    return sorted(transformados, key=lambda r: (0 if r['riesgo'] == 'ALTO' else 1,
                                                r['cantidad']))
