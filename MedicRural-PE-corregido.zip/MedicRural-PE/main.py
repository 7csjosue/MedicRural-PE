"""MedicRural-PE: gestión de medicamentos en establecimientos rurales."""
from inventario import cargar_inventario, registrar_medicamento
from prioridades import establecimientos_en_riesgo, nivel_riesgo


def mostrar(registros):
    if not registros:
        print('No hay registros para mostrar.')
        return
    for r in registros:
        print(f"{r['establecimiento']} | {r['medicamento']} | "
              f"Stock: {r['cantidad']} | Mínimo: {r['minimo']} | "
              f"Riesgo: {r.get('riesgo', nivel_riesgo(r))}")


def pedir_entero(mensaje):
    while True:
        try:
            numero = int(input(mensaje))
            if numero >= 0:
                return numero
        except ValueError:
            pass
        print('Ingresa un número entero igual o mayor que cero.')


def main():
    registros = cargar_inventario()
    while True:
        print('\n=== MEDICRURAL-PE ===')
        print('1. Registrar medicamento')
        print('2. Ver inventario')
        print('3. Ver establecimientos en riesgo')
        print('4. Salir')
        opcion = input('Elige una opción: ').strip()
        if opcion == '1':
            establecimiento = input('Establecimiento rural: ')
            medicamento = input('Medicamento: ')
            cantidad = pedir_entero('Cantidad disponible: ')
            minimo = pedir_entero('Stock mínimo: ')
            try:
                registrar_medicamento(registros, establecimiento, medicamento, cantidad, minimo)
                print('Registro guardado en medicamentos.txt.')
            except ValueError as error:
                print(error)
        elif opcion == '2':
            mostrar(registros)
        elif opcion == '3':
            mostrar(establecimientos_en_riesgo(registros))
        elif opcion == '4':
            print('Hasta luego.')
            break
        else:
            print('Opción inválida.')


if __name__ == '__main__':
    main()
